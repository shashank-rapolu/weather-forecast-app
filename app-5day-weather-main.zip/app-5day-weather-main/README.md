

https://customtkinter.tomschimansky.com/documentation/

<img src="images/screenshot.JPG" alt="screenshot" width="400"/><br>
<br>
<br>
<br>



<img src="images/screenshot2.JPG" alt="screenshot2" width="1200"/><br>